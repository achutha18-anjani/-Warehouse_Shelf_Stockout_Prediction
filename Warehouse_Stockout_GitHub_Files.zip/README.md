# Warehouse Stockout Prediction

## Project Overview
This project explores image-based product monitoring for warehouse
inventory management using the AgriShelf dataset.

The current implementation estimates the number of visible products
in an image using image processing and machine learning.

## Dataset
- Dataset: AgriShelf
- Verified images: 2,443
- Product categories: 7
- Valid annotated objects: 24,309
- Sources: IntelSense and Smartphone

## Data Preparation
- Annotation and image matching
- Coordinate validation
- Exclusion of 11 out-of-boundary points
- Handling of one incomplete annotation line
- Creation of a final training manifest

## Model
- Algorithm: Extra Trees Regressor
- Feature extraction: Histogram of Oriented Gradients (HOG)
- Number of estimators: 150
- Minimum samples per leaf: 2
- Random state: 42

## Model Evaluation

| Metric | Result |
|---|---:|
| Training images | 1,954 |
| Testing images | 489 |
| MAE | 1.1403 |
| RMSE | 3.0263 |
| R2 Score | 0.9418 |

## Project Files
- object_count_model.pkl: Trained model
- final_training_manifest.csv: Final training data manifest
- final_annotation_manifest.csv: Annotation summary
- final_image_annotation_matching.csv: Image-annotation matching
- image_coordinate_validation.csv: Coordinate validation
- model_evaluation_metrics.csv: Evaluation metrics
- model_test_predictions.csv: Test predictions
- out_of_bounds_report.csv: Boundary-point report

## Important Limitation
The current dataset contains product images and object-centroid
annotations, but does not contain actual warehouse stock levels,
sales records, replenishment records, or stockout labels.

Therefore, the current model performs visible product-count
estimation. It is a supporting component for a future stockout
prediction system, not a validated stockout prediction model.

## Future Scope
- Integrate real warehouse inventory data.
- Collect historical sales and replenishment records.
- Define and validate stockout labels.
- Develop and evaluate a time-based stockout prediction model.

## Technologies
- Python
- OpenCV
- HOG feature extraction
- Scikit-learn
- Extra Trees Regressor
- Google Colab